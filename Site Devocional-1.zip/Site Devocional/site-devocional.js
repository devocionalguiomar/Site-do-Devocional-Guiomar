document.addEventListener("DOMContentLoaded", function () {


    const menuButton = document.querySelector(".menu-toggle");
    const navigation = document.querySelector(".header nav");

    if (menuButton && navigation) {

        menuButton.addEventListener("click", function () {

            const aberto = navigation.classList.toggle("open");

            menuButton.textContent = aberto ? "✕" : "☰";

            menuButton.setAttribute(
                "aria-expanded",
                aberto
            );

        });


        navigation.querySelectorAll("a").forEach(function (link) {

            link.addEventListener("click", function () {

                navigation.classList.remove("open");

                menuButton.textContent = "☰";

                menuButton.setAttribute(
                    "aria-expanded",
                    "false"
                );

            });

        });

    }


    const paginaAtual = window.location.pathname
        .split("/")
        .pop()
        .toLowerCase() || "index.html";

    const links = document.querySelectorAll(".header nav a");

    links.forEach(function (link) {

        const destino = link.getAttribute("href");

        if (!destino) return;

        const arquivoDestino = destino
            .split("/")
            .pop()
            .split("#")[0]
            .toLowerCase();

        if (
            arquivoDestino === paginaAtual &&
            !destino.includes("#")
        ) {

            link.classList.add("ativo");

        } else {

            link.classList.remove("ativo");

        }

    });


    document.querySelectorAll('a[href*="#"]').forEach(function (link) {

        link.addEventListener("click", function (event) {

            const url = new URL(link.href);

            const mesmaPagina =
                url.origin === window.location.origin &&
                url.pathname === window.location.pathname;

            if (!mesmaPagina || !url.hash) return;

            const destino = document.querySelector(url.hash);

            if (destino) {

                event.preventDefault();

                destino.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

                history.pushState(null, "", url.hash);

            }

        });

    });

});